﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");


using System;
using System.Threading;

namespace Threading
{
    class Program
    {

        static void method1()
        {
            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine("Method1 : "+ i);

                if(i==5)
                {
                    Console.WriteLine("Thread in Sleep of 6 sec ");
                    Thread.Sleep(6000);
                }
            }
        }

        static void method2()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Method2 : " + i);

                //Thread.Sleep(9000);
            }
        }
        static void Main(string[] args)
        {
           
            Thread t1 = new Thread(method1);
            Thread t2 = new Thread(method2);    
            
            Thread th = Thread.CurrentThread;
            th.Name = "MainThread";

            Console.WriteLine("Name of Thread : " + th.Name);

            t1.Start();
            t2.Start();

            Console.ReadKey();
        }
    }
}