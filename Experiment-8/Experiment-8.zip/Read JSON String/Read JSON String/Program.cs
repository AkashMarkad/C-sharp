﻿using System;  
using System.Collections.Generic;  
using Newtonsoft.Json;  
  

namespace JSON
{
    public class MyDetail
    {
        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
    }
    public class JSON
    {
        static void Main(string[] args)
        {
            string jsonData = @"{ 'FirstName': 'Akash', 'LastName': 'Markad'}";

            var myDetails = JsonConvert.DeserializeObject<MyDetail>(jsonData);
            Console.WriteLine(string.Concat("Hi ", myDetails.FirstName, " " + myDetails.LastName));
            Console.ReadLine();
        }
    }
    
}

