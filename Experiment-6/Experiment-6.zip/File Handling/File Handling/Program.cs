﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;
using System.IO;

namespace File_Handling
{
    class File_Operation
    {
        public void WriteFile()


        {

            FileStream fs = new FileStream("File.txt", FileMode.Append, FileAccess.Write);

            StreamWriter sw = new StreamWriter(fs);

            Console.WriteLine("Write into file : ");

            string str = Console.ReadLine();

            sw.WriteLine(str);

            sw.Close();

        }


        static void Main(string[] args)
        {
            File_Operation op = new File_Operation();
            op.WriteFile();
            
            Console.ReadKey();

        }
    }
}


