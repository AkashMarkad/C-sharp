﻿using System;
using System.IO;

namespace File_Handling
{
    class File_Read
    {
        public void ReadFile()
        {

        //C:\\OneDrive\\Desktop\\FileRead.txt

            string data;

            Console.WriteLine("Enter File Name : ");
            string FileName = Console.ReadLine();

            FileStream fs = new FileStream(FileName, FileMode.Open, FileAccess.Read);


            Console.WriteLine("Content of the file : ");

            using (StreamReader sr = new StreamReader(fs))
            {
                data = sr.ReadToEnd();
            }
            Console.WriteLine(data);
            Console.ReadLine();

        }
        static void Main(string[] args)
        {
            File_Read op = new File_Read();

            op.ReadFile();

            Console.ReadKey();
        }
    }
}